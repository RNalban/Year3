/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;

/**
 *
 * @author rn210
 */
public class Customer {
    private int id;
    private String Username;
    private String Name;
    private String Password;
    public String getName(){
        return Name;
    }
    public void setName(String Name){
        this.Name=Name;
    }
     public String getUsername(){
        return Username;
    }
    public void setUsername(String Username){
        this.Username=Username;
    }
    public String getPassword(){
        return Password;
    }
    public void setPassword(String Password){
        this.Password=Password;
    }
    
 
   
public int getid(){
        return id;
    }
    public void setid(int id){
        this.id=id;
    }
   
}
