/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rn210
 */
@WebServlet("/list")
public class list extends HttpServlet {
    private static final long serialVersionID=1L;
 public list(){
     super();
 }
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        String make=request.getParameter("make");
        out.println("<h1>Display records</h1>");
        out.println("<table border=3><tr><th>Car_id</th><th>Location_id</th><th>Make</th><th>model</th><th>mileage</th><th>year</th><th>price</th></tr>");
        try{
            Class.forName("com.mysql.jdbc.Driver");
         Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","rnaug1998");
         Statement st=con.createStatement();
         ResultSet rs=st.executeQuery("select * from car where make ='"+make+"'");
         while(rs.next()){
             out.print("<tr><td>");
             out.println(rs.getInt(1));
             out.println("</td>");
             out.println("<td>");
             out.print(rs.getInt(2));
             out.print("</td>");
              out.println("<td>");
             out.print(rs.getString(3));
             out.print("</td>");
              out.println("<td>");
             out.print(rs.getString(4));
             out.print("</td>");
              out.println("<td>");
             out.print(rs.getInt(5));
             out.print("</td>");
              out.println("<td>");
             out.print(rs.getInt(6));
             out.print("</td>");
              out.println("<td>");
             out.print(rs.getInt(7));
             out.print("</td>");
             
             
             
             
             
         }
         
        } catch (Exception ex) {
        System.out.println(ex);
     }
        out.println("</table>");
    }

  
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
