/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;

/**
 *
 * @author rn210
 */
public interface Provider {
    String uname="root";
    String pwd="rnaug1998";
    String conUrl="jdbc:mysql://localhost:3306/vehicle";
    
}
