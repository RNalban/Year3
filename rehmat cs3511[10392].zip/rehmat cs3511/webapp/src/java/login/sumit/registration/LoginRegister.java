/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rn210
 */
@WebServlet("/loginRegister")
public class LoginRegister extends HttpServlet {
private static final long serialVersionID=1L;
    
   public LoginRegister(){
       
   }
@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        CustomerDAO cd= new CustomerDAOImp();
    String userName=request.getParameter("username");
    String password=request.getParameter("password");
    String submitType=request.getParameter("submit");
    Customer c=cd.getCustomer(userName, password);
    if(submitType.equals("login") && c!=null && c.getName()!=null){
         request.setAttribute("message",c.getName()); 
        request.getRequestDispatcher("welcome.jsp").forward(request,response);
    }else if(submitType.equals("register")){
       c.setName(request.getParameter("name"));
       c.setUsername(userName);
       c.setPassword(password);
       
       cd.insertCustomer(c);
       request.setAttribute("message","registration done pls login" );
       request.getRequestDispatcher("login.jsp").forward(request, response);
    }else{
        request.setAttribute("message","Data not Found , pls Register");
        request.getRequestDispatcher("login.jsp").forward(request,response);
    }
    
    
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
