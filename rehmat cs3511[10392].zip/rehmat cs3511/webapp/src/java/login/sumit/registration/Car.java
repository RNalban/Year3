/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;

/**
 *
 * @author rn210
 */
public class Car {
    private String make;
    private int year;
    private double price;
    private String model;
    private int carid;
    private int locationID;
    private double mileage;
     public String getmake(){
        return make;
    }
    public void setmake(String make){
        this.make=make;
    }
     public int getyear(){
        return year;
    }
    public void setyear(int year){
        this.year=year;
    }
    public double getprice(){
        return price;
    }
    public void setprice(double price){
        this.price=price;
    }
     public String getmodel(){
        return model;
    }
    public void setmodel(String model){
        this.model=model;
    }
     public int getcid(){
        return carid;
    }
    public void setcid(int carid){
        this.carid=carid;
    }
    public int getLID(){
        return locationID;
    }
    public void setLID(int locationid){
        this.locationID=locationID;
}
    public double getmileage(){
        return mileage;
    }
    public void setmileage(double mileage){
        this.mileage=mileage;
    }

  

   
}