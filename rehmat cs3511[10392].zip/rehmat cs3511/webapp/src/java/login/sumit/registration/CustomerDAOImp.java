/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author rn210
 */
    public class CustomerDAOImp implements CustomerDAO{
static Connection con;
static PreparedStatement ps;
    
@Override
    public int insertCustomer(Customer c) {
        int status=0;
        try{
           con=connectProvider.getCon();
           ps=con.prepareStatement("insert into customers(name,username,password) values('"+c.getName()+"','"+c.getUsername()+"','"+c.getPassword()+"')");
          
           status=ps.executeUpdate();
           con.close();
        }catch(Exception ex){
            System.out.println(ex);
        }
       return status;     
    }

    
@Override
    public Customer getCustomer(String Username,String Password) {
      Customer c=new Customer();
        try{
           con=connectProvider.getCon();
           ps=con.prepareStatement("select * from customers where username=? and password=?;");
           ps.setString(1,Username);
           ps.setString(2,Password);
           ResultSet rs=ps.executeQuery();
           while(rs.next()){
               c.setid(rs.getInt(1));
               c.setName(rs.getString(2));
               c.setUsername(rs.getString(3)); 
               c.setPassword(rs.getString(4));
           
           }
        }catch(Exception ex){
            System.out.println(ex);
        }
        return c;
    }

   

    
    
}
