/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.sumit.registration;

/**
 *
 * @author rn210
 */
public class Sellers {
    private int saleID;
    private String salename;
     private int phone;
    private int locationID;
    
    public int getsaleID(){
        return saleID;
    }
    public void setsaleID(int saleID){
        this.saleID=saleID;
    }
     public String getsalename(){
        return salename;
    }
    public void setsalename(String salename){
        this.salename=salename;
    }
     public int getphone(){
        return phone;
    }
    public void setphone(int phone){
        this.phone=phone;
    }
    public int getLID(){
        return locationID;
    }
    public void setLID(int locationID){
        this.locationID=locationID;
    }
    
}
