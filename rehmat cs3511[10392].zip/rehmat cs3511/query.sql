create database vehicle;
use vehicle;
create table customers(customer_id int not null auto_increment,name varchar(20),username varchar(40),password varchar(20),primary key(customer_id));
insert into customers(name,username,password) values("nalban","nalban@gmail.com","Zara1234");

create table location(location_id int not null auto_increment,location_name varchar(20), primary key(location_id));
insert into location(location_name) values("Dubai");
insert into location(location_name) values("Sharjah");
insert into location(location_name) values("Ajman");
insert into location(location_name) values("Abu Dhabi");
insert into location(location_name) values("Ras Al Khaimah");
insert into location(location_name) values("Al Ain");
insert into location(location_name) values("Fujairah");

create table car(car_id int not null auto_increment,location_id int, make varchar(20),model varchar(20),mileage int,year int, price int);
alter table car add foreign key(location_id) references location(location_id);

create table saleperson(sale_id int not null auto_increment,location_id int,sale_name varchar(20),phone int,primary key(sale_id));
alter table saleperson add foreign key(location_id) references location(location_id);

 insert into saleperson(location_id,sale_name,phone)values(1,"Fawad Motors",0526225221);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0525584427);
 insert into saleperson(location_id,sale_name,phone)values(1,"Fawad Motors",0502526007);
insert into saleperson(location_id,sale_name,phone)values(1,"New Cars LLC",043333890);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0507771831);
 insert into saleperson(location_id,sale_name,phone)values(1,"Al Futtaim",600567005);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0501989479);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0543571879);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0567662213);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0582562898);
insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0501989479);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0553900992);
 insert into saleperson(location_id,sale_name,phone)values(1,"Yalla Motor",0505798639);

create table deal(deal_id int not null auto_increment,customer_id int,car_id int,sale_id int,price int,primary key(deal_id));
alter table deal add foreign key(customer_id) references customers(customer_id);
alter table deal add foreign key(sale_id) references saleperson(sale_id);
alter table saleperson add foreign key(location_id) references location(location_id);

create table visits(visit_id not null auto_increment, customer_id int,sale_id int,visitDate varchar(20), testdrive char(4) );
alter table visits add foreign key(customer_id) references customers(customer_id);
alter table visits add foriegn key(sale_id) references saleperson(sale_id);
